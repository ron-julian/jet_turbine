using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class quitmethod : MonoBehaviour
{
 public void quit(){
    Application.Quit();
 }
}
